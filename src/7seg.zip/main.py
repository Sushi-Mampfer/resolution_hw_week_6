import time
from neopixel import NeoPixel
from machine import Pin
import dht

class SevenSegment:
    """
    A simple wrapper for 7 segment displays with LED matrixes.
    The matrix has to have 9 rows and n*6-1 cols, where n is the amount of numbers.
    To create a new display use SevenSegment(n, pin, (color)), where n is again the amount of numbers, pin the pin it'S connected to and color is the color as a rgb tupel, which defaults to white.
    To use it use the write method, which writes a new number on the display, if the number is longer than the display it does nothing. It also accepts an optional rgb color tupel.
    To change the color use the set_color method, which takes an rgb tupel and redraws the screen in the new color.
    """
    def __init__(self, numbers, pin, color = (255, 255, 255)):
        self.numbers = numbers
        self.pixels = NeoPixel(Pin(pin), (numbers*6-1)*9)
        self.state = "".join(["0" for i in range(numbers)])
        self.color = color

    def write(self, numbers, color = None):
        if color:
            self.color = color

        numbers = str(numbers)

        if len(numbers.replace(".", "")) > self.numbers:
            return

        for i in range((self.numbers*6-1)*9):
            self.pixels[i] = (0, 0, 0)

        if "." in numbers:
            self.pixels[(self.numbers*6-1)*8+(self.numbers-len(numbers.split(".")[1]))*6-1] = self.color
        for i, n in enumerate(f"{numbers.replace(".", ""):>{self.numbers}}"):
            if n == "0":
                self.t(i)
                self.tr(i)
                self.br(i)
                self.b(i)
                self.bl(i)
                self.tl(i)
            elif n == "1":
                self.tr(i)
                self.br(i)
            elif n == "2":
                self.t(i)
                self.tr(i)
                self.b(i)
                self.bl(i)
                self.m(i)
            elif n == "3":
                self.t(i)
                self.tr(i)
                self.br(i)
                self.b(i)
                self.m(i)
            elif n == "4":
                self.tr(i)
                self.br(i)
                self.tl(i)
                self.m(i)
            elif n == "5":
                self.t(i)
                self.br(i)
                self.b(i)
                self.tl(i)
                self.m(i)
            elif n == "6":
                self.t(i)
                self.br(i)
                self.b(i)
                self.bl(i)
                self.tl(i)
                self.m(i)
            elif n == "7":
                self.t(i)
                self.tr(i)
                self.br(i)
            elif n == "8":
                self.t(i)
                self.tr(i)
                self.br(i)
                self.b(i)
                self.bl(i)
                self.tl(i)
                self.m(i)
            elif n == "9":
                self.t(i)
                self.tr(i)
                self.br(i)
                self.b(i)
                self.tl(i)
                self.m(i)
            elif n == "-":
                self.m(i)

        self.state = numbers

        self.pixels.write()

    def set_color(self, color):
        self.color = color
        self.write(self.state)

    def t(self, num):
        pos = 6*num+1
        self.pixels[pos] = self.color
        self.pixels[pos+1] = self.color
        self.pixels[pos+2] = self.color
    def tr(self, num):
        pos = self.numbers*6+(self.numbers-num-1)*6-1
        self.pixels[pos] = self.color
        self.pixels[pos+num*12+9] = self.color
        self.pixels[pos+self.numbers*12-2] = self.color
    def br(self, num):
        pos = (self.numbers*6-1)*5+(self.numbers-num-1)*6
        self.pixels[pos] = self.color
        self.pixels[pos+num*12+9] = self.color
        self.pixels[pos+self.numbers*12-2] = self.color
    def b(self, num):
        pos = 6*num+(self.numbers*6-1)*8+1
        self.pixels[pos] = self.color
        self.pixels[pos+1] = self.color
        self.pixels[pos+2] = self.color
    def bl(self, num):
        pos = (self.numbers*6-1)*5+(self.numbers-num-1)*6+4
        self.pixels[pos] = self.color
        self.pixels[pos+num*12+1] = self.color
        self.pixels[pos+self.numbers*12-2] = self.color
    def tl(self, num):
        pos = self.numbers*6-1+(self.numbers-num-1)*6+4
        self.pixels[pos] = self.color
        self.pixels[pos+num*12+1] = self.color
        self.pixels[pos+self.numbers*12-2] = self.color
    def m(self, num):
        pos = 6*num+(self.numbers*6-1)*4+1
        self.pixels[pos] = self.color
        self.pixels[pos+1] = self.color
        self.pixels[pos+2] = self.color

time.sleep(0.1)

seg = SevenSegment(4, 10)
d = dht.DHT22(machine.Pin(9))
while True:
    d.measure()
    temp = d.temperature()
    seg.write(temp)
    if temp < 0:
        seg.write(temp, color=(172, 213, 243))
    elif temp > 30:
        seg.write(temp, color=(254, 196, 127))
    else:
        seg.write(temp, color=(255, 255, 255))
    time.sleep(0.1)
